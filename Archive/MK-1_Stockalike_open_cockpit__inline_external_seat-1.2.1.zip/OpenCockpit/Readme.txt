
------------------ AVC --------------------

This mod include MiniAVC version checker and
use internet connection to work. If you wish
to know what type of data transmitted
read AVC online Readme 
http://ksp.cybutek.net/kspavc/Documents/README.htm